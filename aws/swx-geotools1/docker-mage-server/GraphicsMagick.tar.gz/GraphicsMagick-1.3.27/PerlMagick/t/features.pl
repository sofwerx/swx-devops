# Configuration-specific test suite definitions.
#

# Create a Perl list containing feature names
@MAGICK_FEATURES=qw(JBIG WEBP JNG JPEG LZMA PNG PS TIFF TTF XML ZLIB);
